from django.db import migrations, models
import django.db.models.deletion


PAYMENT_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("SUCCESS", "Success"),
    ("FAILED", "Failed"),
    ("REFUNDED", "Refunded"),
]

CASHIER_SESSION_STATUS_CHOICES = [
    ("OPEN", "Open"),
    ("CLOSED", "Closed"),
]

INVOICE_STATUS_CHOICES = [
    ("DRAFT", "Draft"),
    ("ISSUED", "Issued"),
    ("CANCELLED", "Cancelled"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("tickets", "0001_initial"),
        ("branches", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="PaymentMethod",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("name", models.CharField(max_length=100)),
                ("is_active", models.BooleanField(default=True)),
            ],
            options={"db_table": "payment_methods"},
        ),
        migrations.CreateModel(
            name="Payment",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                ("payment_code", models.CharField(max_length=30, unique=True)),
                (
                    "booking",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="tickets.TicketBooking",
                        null=True,
                        blank=True,
                        related_name="payments",
                    ),
                ),
                # consignment FK will be added in consignments migration
                ("consignment_id", models.BigIntegerField(null=True, blank=True)),
                ("amount", models.DecimalField(max_digits=15, decimal_places=2)),
                (
                    "method",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="payments.PaymentMethod",
                    ),
                ),
                ("status", models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default="PENDING")),
                ("transaction_ref", models.CharField(max_length=100, blank=True, null=True)),
                (
                    "cashier",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                        related_name="processed_payments",
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True,
                        blank=True,
                    ),
                ),
                ("paid_at", models.DateTimeField(null=True, blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "payments",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["booking"], name="idx_payments_booking"),
                ],
            },
        ),
        migrations.CreateModel(
            name="CashierSession",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "cashier",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="accounts.UserAccount",
                        related_name="cashier_sessions",
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="branches.Branch",
                    ),
                ),
                ("opened_at", models.DateTimeField(auto_now_add=True)),
                ("closed_at", models.DateTimeField(null=True, blank=True)),
                ("opening_cash", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("closing_cash", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("total_sales", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("status", models.CharField(max_length=20, choices=CASHIER_SESSION_STATUS_CHOICES, default="OPEN")),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "cashier_sessions", "ordering": ["-opened_at"]},
        ),
        migrations.CreateModel(
            name="Invoice",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("invoice_no", models.CharField(max_length=50, unique=True)),
                ("series", models.CharField(max_length=10)),
                (
                    "booking",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="tickets.TicketBooking",
                        null=True,
                        blank=True,
                        related_name="invoices",
                    ),
                ),
                (
                    "group_contract",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="tickets.GroupContract",
                        null=True,
                        blank=True,
                        related_name="invoices",
                    ),
                ),
                ("buyer_name", models.CharField(max_length=255, blank=True, null=True)),
                ("buyer_tax_code", models.CharField(max_length=20, blank=True, null=True)),
                ("buyer_address", models.TextField(blank=True, null=True)),
                ("subtotal", models.DecimalField(max_digits=15, decimal_places=2)),
                ("vat_rate", models.DecimalField(max_digits=5, decimal_places=2, default=10.00)),
                ("vat_amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("total_amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("status", models.CharField(max_length=20, choices=INVOICE_STATUS_CHOICES, default="DRAFT")),
                ("e_invoice_code", models.CharField(max_length=100, blank=True, null=True)),
                ("issued_at", models.DateTimeField(null=True, blank=True)),
                (
                    "issued_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "invoices", "ordering": ["-created_at"]},
        ),
    ]
