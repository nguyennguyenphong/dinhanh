from django.db import migrations, models
import django.db.models.deletion
import django.contrib.postgres.fields
import uuid


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Role",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("name", models.CharField(max_length=100, unique=True)),
                ("description", models.TextField(blank=True, null=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "roles", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Permission",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("codename", models.CharField(max_length=150, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("module", models.CharField(max_length=100)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "permissions", "ordering": ["module", "codename"]},
        ),
        migrations.AddField(
            model_name="Role",
            name="permissions",
            field=models.ManyToManyField(
                to="accounts.Permission",
                through="accounts.RolePermission",
                related_name="roles",
                blank=True,
            ),
        ),
        migrations.CreateModel(
            name="RolePermission",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "role",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="accounts.Role",
                    ),
                ),
                (
                    "permission",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="accounts.Permission",
                    ),
                ),
            ],
            options={
                "db_table": "role_permissions",
                "unique_together": {("role", "permission")},
            },
        ),
        migrations.CreateModel(
            name="UserAccount",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("uuid", models.UUIDField(default=uuid.uuid4, unique=True, editable=False)),
                ("username", models.CharField(max_length=150, unique=True)),
                ("email", models.EmailField(max_length=254, unique=True)),
                ("password_hash", models.CharField(max_length=255)),
                ("full_name", models.CharField(max_length=255)),
                ("phone", models.CharField(max_length=20, blank=True, null=True)),
                ("avatar", models.CharField(max_length=500, blank=True, null=True)),
                # branch FK added in branches migration
                ("is_active", models.BooleanField(default=True)),
                ("is_staff", models.BooleanField(default=False)),
                ("is_superuser", models.BooleanField(default=False)),
                ("last_login", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "user_accounts", "ordering": ["username"]},
        ),
        migrations.CreateModel(
            name="UserRole",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="accounts.UserAccount",
                        related_name="user_roles",
                    ),
                ),
                (
                    "role",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="accounts.Role",
                    ),
                ),
            ],
            options={
                "db_table": "user_roles",
                "unique_together": {("user", "role")},
            },
        ),
        migrations.AddField(
            model_name="UserAccount",
            name="roles",
            field=models.ManyToManyField(
                to="accounts.Role",
                through="accounts.UserRole",
                related_name="users",
                blank=True,
            ),
        ),
        migrations.CreateModel(
            name="AuditLog",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("username", models.CharField(max_length=150, blank=True, null=True)),
                ("action", models.CharField(max_length=50)),
                ("module", models.CharField(max_length=100)),
                ("object_id", models.CharField(max_length=50, blank=True, null=True)),
                ("object_repr", models.CharField(max_length=500, blank=True, null=True)),
                ("changes", models.JSONField(null=True, blank=True)),
                ("ip_address", models.GenericIPAddressField(null=True, blank=True)),
                ("user_agent", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "db_table": "audit_logs",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["user"], name="idx_audit_user"),
                    models.Index(fields=["-created_at"], name="idx_audit_created"),
                ],
            },
        ),
    ]
