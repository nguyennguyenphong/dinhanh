from django.db import migrations, models
import django.db.models.deletion
import django.contrib.postgres.fields


TRIP_STATUS_CHOICES = [
    ("SCHEDULED", "Scheduled"),
    ("BOARDING", "Boarding"),
    ("DEPARTED", "Departed"),
    ("ARRIVED", "Arrived"),
    ("CANCELLED", "Cancelled"),
    ("DELAYED", "Delayed"),
]

DISPATCH_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("ISSUED", "Issued"),
    ("DEPARTED", "Departed"),
]

STAFF_ROLE_CHOICES = [
    ("DRIVER", "Driver"),
    ("ASSISTANT", "Bus Assistant"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("routes", "0001_initial"),
        ("vehicles", "0001_initial"),
        ("hr", "0001_initial"),
        ("branches", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="TripSchedule",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                (
                    "route",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Route",
                        related_name="schedules",
                    ),
                ),
                ("departure_time", models.TimeField()),
                ("arrival_time", models.TimeField(null=True, blank=True)),
                # days_of_week stored as ArrayField: [1..7] where 1=Mon
                ("days_of_week", models.JSONField(default=list)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "trip_schedules", "ordering": ["departure_time"]},
        ),
        migrations.CreateModel(
            name="Trip",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                (
                    "schedule",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="trips.TripSchedule",
                        null=True,
                        blank=True,
                        related_name="trips",
                    ),
                ),
                (
                    "route",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Route",
                        related_name="trips",
                    ),
                ),
                (
                    "vehicle",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="vehicles.Vehicle",
                        null=True,
                        blank=True,
                        related_name="trips",
                    ),
                ),
                (
                    "seat_map",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="vehicles.SeatMap",
                        null=True,
                        blank=True,
                    ),
                ),
                ("departure_time", models.DateTimeField()),
                ("estimated_arrival", models.DateTimeField(null=True, blank=True)),
                ("actual_departure", models.DateTimeField(null=True, blank=True)),
                ("actual_arrival", models.DateTimeField(null=True, blank=True)),
                ("status", models.CharField(max_length=30, choices=TRIP_STATUS_CHOICES, default="SCHEDULED")),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True,
                        blank=True,
                        related_name="trips",
                    ),
                ),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "trips",
                "ordering": ["-departure_time"],
                "indexes": [
                    models.Index(fields=["departure_time"], name="idx_trips_departure"),
                    models.Index(fields=["status"], name="idx_trips_status"),
                    models.Index(fields=["route"], name="idx_trips_route"),
                ],
            },
        ),
        migrations.CreateModel(
            name="TripStaff",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="trips.Trip",
                        related_name="staff_assignments",
                    ),
                ),
                (
                    "employee",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="hr.Employee",
                        related_name="trip_assignments",
                    ),
                ),
                ("role", models.CharField(max_length=30, choices=STAFF_ROLE_CHOICES)),
                (
                    "shift_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="hr.ShiftType",
                        null=True,
                        blank=True,
                    ),
                ),
            ],
            options={
                "db_table": "trip_staff",
                "unique_together": {("trip", "employee")},
            },
        ),
        migrations.CreateModel(
            name="TripPrice",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "route",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="routes.Route",
                        related_name="prices",
                    ),
                ),
                ("seat_type", models.CharField(max_length=30, default="SEAT")),
                ("price", models.DecimalField(max_digits=15, decimal_places=2)),
                ("valid_from", models.DateField()),
                ("valid_to", models.DateField(null=True, blank=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "trip_prices", "ordering": ["-valid_from"]},
        ),
        migrations.CreateModel(
            name="DispatchOrder",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "trip",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="trips.Trip",
                        related_name="dispatch_order",
                    ),
                ),
                (
                    "issued_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("issued_at", models.DateTimeField(null=True, blank=True)),
                ("notes", models.TextField(blank=True, null=True)),
                ("status", models.CharField(max_length=20, choices=DISPATCH_STATUS_CHOICES, default="PENDING")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "dispatch_orders"},
        ),
    ]
