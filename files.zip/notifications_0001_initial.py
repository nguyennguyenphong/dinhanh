from django.db import migrations, models
import django.db.models.deletion


CHANNEL_CHOICES = [
    ("SMS", "SMS"),
    ("EMAIL", "Email"),
    ("PUSH", "Push Notification"),
]

NOTIFICATION_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("SENT", "Sent"),
    ("FAILED", "Failed"),
]

RECIPIENT_TYPE_CHOICES = [
    ("USER", "System User"),
    ("CUSTOMER", "Customer"),
    ("EMPLOYEE", "Employee"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="NotificationTemplate",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=50, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("channel", models.CharField(max_length=20, choices=CHANNEL_CHOICES)),
                ("subject", models.CharField(max_length=500, blank=True, null=True)),
                ("body", models.TextField()),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "notification_templates"},
        ),
        migrations.CreateModel(
            name="Notification",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "template",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="notifications.NotificationTemplate",
                        null=True, blank=True,
                    ),
                ),
                ("recipient_type", models.CharField(max_length=20, choices=RECIPIENT_TYPE_CHOICES)),
                ("recipient_id", models.IntegerField(null=True, blank=True)),
                ("recipient_phone", models.CharField(max_length=20, blank=True, null=True)),
                ("recipient_email", models.EmailField(blank=True, null=True)),
                ("channel", models.CharField(max_length=20, choices=CHANNEL_CHOICES)),
                ("subject", models.CharField(max_length=500, blank=True, null=True)),
                ("body", models.TextField()),
                ("status", models.CharField(max_length=20, choices=NOTIFICATION_STATUS_CHOICES, default="PENDING")),
                ("sent_at", models.DateTimeField(null=True, blank=True)),
                ("error_msg", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "db_table": "notifications",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["status"], name="idx_notifications_status"),
                ],
            },
        ),
    ]
