from django.db import migrations, models
import django.db.models.deletion


DISCOUNT_TYPE_CHOICES = [
    ("PERCENT", "Percentage"),
    ("FIXED_AMOUNT", "Fixed Amount"),
]

AFTER_SALES_TYPE_CHOICES = [
    ("VOUCHER", "Voucher"),
    ("LOYALTY_POINTS", "Loyalty Points"),
    ("GIFT", "Gift"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("tickets", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Promotion",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=50, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("description", models.TextField(blank=True, null=True)),
                ("discount_type", models.CharField(max_length=20, choices=DISCOUNT_TYPE_CHOICES)),
                ("discount_value", models.DecimalField(max_digits=10, decimal_places=2)),
                ("min_order_amount", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("max_discount", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("usage_limit", models.IntegerField(null=True, blank=True)),
                ("usage_count", models.IntegerField(default=0)),
                ("applicable_routes", models.JSONField(default=list, blank=True)),
                ("applicable_seat_types", models.JSONField(default=list, blank=True)),
                ("valid_from", models.DateTimeField()),
                ("valid_to", models.DateTimeField(null=True, blank=True)),
                ("is_active", models.BooleanField(default=True)),
                (
                    "created_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True, blank=True,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "promotions", "ordering": ["-valid_from"]},
        ),
        migrations.CreateModel(
            name="PromotionUsage",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "promotion",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="promotions.Promotion",
                        related_name="usages",
                    ),
                ),
                (
                    "booking",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="tickets.TicketBooking",
                        related_name="promotion_usages",
                    ),
                ),
                ("discount_applied", models.DecimalField(max_digits=15, decimal_places=2)),
                ("used_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "promotion_usages"},
        ),
        migrations.CreateModel(
            name="AfterSale",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=50, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("description", models.TextField(blank=True, null=True)),
                ("type", models.CharField(max_length=30, choices=AFTER_SALES_TYPE_CHOICES)),
                ("value", models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)),
                ("conditions", models.JSONField(default=dict)),
                ("is_active", models.BooleanField(default=True)),
                (
                    "created_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True, blank=True,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "after_sales"},
        ),
    ]
