from django.db import migrations, models
import django.db.models.deletion


VEHICLE_TYPE_CHOICES = [
    ("BUS", "Bus"),
    ("SLEEPER_BUS", "Sleeper Bus"),
    ("LIMOUSINE", "Limousine"),
]

VEHICLE_STATUS_CHOICES = [
    ("AVAILABLE", "Available"),
    ("IN_TRIP", "In Trip"),
    ("MAINTENANCE", "Maintenance"),
    ("INACTIVE", "Inactive"),
]

SEAT_TYPE_CHOICES = [
    ("SEAT", "Seat"),
    ("BED", "Bed"),
    ("VIP", "VIP"),
]

MAINTENANCE_TYPE_CHOICES = [
    ("SCHEDULED", "Scheduled"),
    ("EMERGENCY", "Emergency"),
]

MAINTENANCE_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("DONE", "Done"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("branches", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="VehicleCategory",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=100)),
                ("seat_count", models.SmallIntegerField()),
                ("vehicle_type", models.CharField(max_length=50, choices=VEHICLE_TYPE_CHOICES)),
                ("description", models.TextField(blank=True, null=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "vehicle_categories", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Vehicle",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("plate_number", models.CharField(max_length=20, unique=True)),
                (
                    "category",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="vehicles.VehicleCategory",
                        related_name="vehicles",
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True,
                        blank=True,
                        related_name="vehicles",
                    ),
                ),
                ("manufacture_year", models.SmallIntegerField(null=True, blank=True)),
                ("brand", models.CharField(max_length=100, blank=True, null=True)),
                ("model", models.CharField(max_length=100, blank=True, null=True)),
                ("color", models.CharField(max_length=50, blank=True, null=True)),
                ("status", models.CharField(max_length=30, choices=VEHICLE_STATUS_CHOICES, default="AVAILABLE")),
                ("registration_expiry", models.DateField(null=True, blank=True)),
                ("insurance_expiry", models.DateField(null=True, blank=True)),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "vehicles", "ordering": ["plate_number"]},
        ),
        migrations.CreateModel(
            name="SeatMap",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "category",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="vehicles.VehicleCategory",
                        related_name="seat_maps",
                    ),
                ),
                ("name", models.CharField(max_length=100)),
                ("total_seats", models.SmallIntegerField()),
                ("layout_config", models.JSONField(default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "seat_maps"},
        ),
        migrations.CreateModel(
            name="Seat",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "seat_map",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="vehicles.SeatMap",
                        related_name="seats",
                    ),
                ),
                ("seat_code", models.CharField(max_length=10)),
                ("seat_type", models.CharField(max_length=30, choices=SEAT_TYPE_CHOICES, default="SEAT")),
                ("deck", models.SmallIntegerField(default=1)),
                ("row_num", models.SmallIntegerField(null=True, blank=True)),
                ("col_num", models.SmallIntegerField(null=True, blank=True)),
                ("is_available", models.BooleanField(default=True)),
            ],
            options={
                "db_table": "seats",
                "unique_together": {("seat_map", "seat_code")},
            },
        ),
        migrations.CreateModel(
            name="VehicleMaintenance",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "vehicle",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="vehicles.Vehicle",
                        related_name="maintenance_records",
                    ),
                ),
                ("type", models.CharField(max_length=30, choices=MAINTENANCE_TYPE_CHOICES)),
                ("description", models.TextField()),
                ("cost", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("vendor", models.CharField(max_length=255, blank=True, null=True)),
                ("scheduled_at", models.DateField(null=True, blank=True)),
                ("completed_at", models.DateField(null=True, blank=True)),
                (
                    "performed_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("status", models.CharField(max_length=20, choices=MAINTENANCE_STATUS_CHOICES, default="PENDING")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "vehicle_maintenance", "ordering": ["-created_at"]},
        ),
    ]
