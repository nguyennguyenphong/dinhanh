from django.db import migrations, models
import django.db.models.deletion


GENDER_CHOICES = [("MALE", "Male"), ("FEMALE", "Female"), ("OTHER", "Other")]

POSITION_CHOICES = [
    ("DRIVER", "Driver"),
    ("ASSISTANT", "Bus Assistant"),
    ("CASHIER", "Cashier"),
    ("DISPATCHER", "Dispatcher"),
    ("MANAGER", "Manager"),
    ("STAFF", "Staff"),
]

ATTENDANCE_STATUS_CHOICES = [
    ("PRESENT", "Present"),
    ("ABSENT", "Absent"),
    ("LATE", "Late"),
    ("HALF_DAY", "Half Day"),
    ("LEAVE", "On Leave"),
]

PAYROLL_STATUS_CHOICES = [
    ("DRAFT", "Draft"),
    ("APPROVED", "Approved"),
    ("PAID", "Paid"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("accounts", "0001_initial"),
        ("branches", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Department",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("name", models.CharField(max_length=100, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "departments", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Employee",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("full_name", models.CharField(max_length=255)),
                ("national_id", models.CharField(max_length=20, blank=True, null=True)),
                ("phone", models.CharField(max_length=20, blank=True, null=True)),
                ("email", models.EmailField(blank=True, null=True)),
                ("date_of_birth", models.DateField(null=True, blank=True)),
                ("gender", models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True, null=True)),
                ("address", models.TextField(blank=True, null=True)),
                ("position", models.CharField(max_length=100, choices=POSITION_CHOICES)),
                (
                    "department",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="hr.Department",
                        null=True,
                        blank=True,
                        related_name="employees",
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True,
                        blank=True,
                        related_name="employees",
                    ),
                ),
                (
                    "user_account",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                        related_name="employee_profile",
                    ),
                ),
                ("hired_at", models.DateField()),
                ("terminated_at", models.DateField(null=True, blank=True)),
                ("is_active", models.BooleanField(default=True)),
                # Driver-specific
                ("license_number", models.CharField(max_length=50, blank=True, null=True)),
                ("license_class", models.CharField(max_length=10, blank=True, null=True)),
                ("license_expiry", models.DateField(null=True, blank=True)),
                # Insurance
                ("social_insurance_no", models.CharField(max_length=20, blank=True, null=True)),
                ("health_insurance_no", models.CharField(max_length=20, blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "employees", "ordering": ["full_name"]},
        ),
        migrations.CreateModel(
            name="ShiftType",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=100)),
                ("start_time", models.TimeField()),
                ("end_time", models.TimeField()),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "shift_types", "ordering": ["start_time"]},
        ),
        migrations.CreateModel(
            name="Attendance",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "employee",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="hr.Employee",
                        related_name="attendances",
                    ),
                ),
                (
                    "shift_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="hr.ShiftType",
                        null=True,
                        blank=True,
                    ),
                ),
                ("work_date", models.DateField()),
                ("check_in", models.DateTimeField(null=True, blank=True)),
                ("check_out", models.DateTimeField(null=True, blank=True)),
                ("status", models.CharField(max_length=20, choices=ATTENDANCE_STATUS_CHOICES, default="PRESENT")),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "db_table": "attendances",
                "ordering": ["-work_date"],
                "unique_together": {("employee", "work_date")},
            },
        ),
        migrations.CreateModel(
            name="Payroll",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "employee",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="hr.Employee",
                        related_name="payrolls",
                    ),
                ),
                ("period_year", models.SmallIntegerField()),
                ("period_month", models.SmallIntegerField()),
                ("base_salary", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("allowances", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("deductions", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("bonus", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("net_salary", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("status", models.CharField(max_length=20, choices=PAYROLL_STATUS_CHOICES, default="DRAFT")),
                (
                    "approved_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("paid_at", models.DateTimeField(null=True, blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "payroll",
                "ordering": ["-period_year", "-period_month"],
                "unique_together": {("employee", "period_year", "period_month")},
            },
        ),
    ]
