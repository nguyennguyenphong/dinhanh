from django.db import migrations, models
import django.db.models.deletion


EXPENSE_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("APPROVED", "Approved"),
    ("REJECTED", "Rejected"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("vehicles", "0001_initial"),
        ("trips", "0001_initial"),
        ("branches", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="ExpenseCategory",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("name", models.CharField(max_length=100)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "expense_categories", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Expense",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "category",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="financials.ExpenseCategory",
                        related_name="expenses",
                    ),
                ),
                (
                    "vehicle",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="vehicles.Vehicle",
                        null=True, blank=True,
                    ),
                ),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="trips.Trip",
                        null=True, blank=True,
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True, blank=True,
                    ),
                ),
                ("title", models.CharField(max_length=255)),
                ("amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("expense_date", models.DateField()),
                ("description", models.TextField(blank=True, null=True)),
                ("attachment", models.CharField(max_length=500, blank=True, null=True)),
                (
                    "submitted_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True, blank=True,
                        related_name="submitted_expenses",
                    ),
                ),
                (
                    "approved_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True, blank=True,
                        related_name="approved_expenses",
                    ),
                ),
                ("status", models.CharField(max_length=20, choices=EXPENSE_STATUS_CHOICES, default="PENDING")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "expenses",
                "ordering": ["-expense_date"],
                "indexes": [
                    models.Index(fields=["expense_date"], name="idx_expenses_date"),
                ],
            },
        ),
        migrations.CreateModel(
            name="FuelAllocation",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "vehicle",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="vehicles.Vehicle",
                        related_name="fuel_allocations",
                    ),
                ),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="trips.Trip",
                        null=True, blank=True,
                    ),
                ),
                ("liters", models.DecimalField(max_digits=8, decimal_places=2)),
                ("price_per_liter", models.DecimalField(max_digits=10, decimal_places=2)),
                ("total_cost", models.DecimalField(max_digits=15, decimal_places=2)),
                (
                    "allocated_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True, blank=True,
                    ),
                ),
                ("allocated_at", models.DateTimeField(auto_now_add=True)),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "fuel_allocations", "ordering": ["-allocated_at"]},
        ),
    ]
