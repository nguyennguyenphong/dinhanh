from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("branches", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Province",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=10, unique=True)),
                ("name", models.CharField(max_length=100)),
            ],
            options={"db_table": "provinces", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Station",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=255)),
                (
                    "province",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Province",
                        related_name="stations",
                    ),
                ),
                ("address", models.TextField(blank=True, null=True)),
                ("latitude", models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)),
                ("longitude", models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "stations", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Route",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=255)),
                (
                    "origin",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Station",
                        related_name="routes_as_origin",
                    ),
                ),
                (
                    "destination",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Station",
                        related_name="routes_as_destination",
                    ),
                ),
                ("distance_km", models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)),
                ("duration_min", models.IntegerField(null=True, blank=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "routes", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="RouteStop",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "route",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="routes.Route",
                        related_name="stops",
                    ),
                ),
                (
                    "station",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="routes.Station",
                    ),
                ),
                ("stop_order", models.SmallIntegerField()),
                ("arrive_offset_min", models.IntegerField(null=True, blank=True)),
                ("depart_offset_min", models.IntegerField(null=True, blank=True)),
            ],
            options={
                "db_table": "route_stops",
                "ordering": ["route", "stop_order"],
                "unique_together": {("route", "stop_order")},
            },
        ),
    ]
