from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Branch",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("address", models.TextField(blank=True, null=True)),
                ("phone", models.CharField(max_length=20, blank=True, null=True)),
                ("email", models.EmailField(blank=True, null=True)),
                (
                    "manager",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                        related_name="managed_branches",
                    ),
                ),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "branches", "ordering": ["name"]},
        ),
        # Add branch FK back to user_accounts (deferred FK)
        migrations.AddField(
            model_name="accounts.UserAccount",
            name="branch",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.SET_NULL,
                to="branches.Branch",
                null=True,
                blank=True,
                related_name="users",
            ),
        ),
    ]
