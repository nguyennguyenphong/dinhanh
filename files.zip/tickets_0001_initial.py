from django.db import migrations, models
import django.db.models.deletion


BOOKING_CHANNEL_CHOICES = [
    ("COUNTER", "Counter"),
    ("ONLINE", "Online"),
    ("AGENT", "Agent"),
]

BOOKING_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("CONFIRMED", "Confirmed"),
    ("CANCELLED", "Cancelled"),
    ("REFUNDED", "Refunded"),
]

TICKET_STATUS_CHOICES = [
    ("ACTIVE", "Active"),
    ("USED", "Used"),
    ("CANCELLED", "Cancelled"),
    ("REFUNDED", "Refunded"),
    ("EXCHANGED", "Exchanged"),
]

REFUND_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("APPROVED", "Approved"),
    ("COMPLETED", "Completed"),
    ("REJECTED", "Rejected"),
]

GROUP_CONTRACT_STATUS_CHOICES = [
    ("DRAFT", "Draft"),
    ("CONFIRMED", "Confirmed"),
    ("CANCELLED", "Cancelled"),
    ("COMPLETED", "Completed"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("trips", "0001_initial"),
        ("vehicles", "0001_initial"),
        ("routes", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Customer",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("full_name", models.CharField(max_length=255)),
                ("phone", models.CharField(max_length=20)),
                ("email", models.EmailField(blank=True, null=True)),
                ("national_id", models.CharField(max_length=20, blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "customers",
                "ordering": ["full_name"],
                "indexes": [
                    models.Index(fields=["phone"], name="idx_customers_phone"),
                ],
            },
        ),
        migrations.CreateModel(
            name="TicketBooking",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                ("booking_code", models.CharField(max_length=30, unique=True)),
                (
                    "customer",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="tickets.Customer",
                        related_name="bookings",
                    ),
                ),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="trips.Trip",
                        related_name="bookings",
                    ),
                ),
                (
                    "booked_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("channel", models.CharField(max_length=30, choices=BOOKING_CHANNEL_CHOICES, default="COUNTER")),
                ("status", models.CharField(max_length=30, choices=BOOKING_STATUS_CHOICES, default="PENDING")),
                ("total_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("discount_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("final_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "ticket_bookings",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["trip"], name="idx_bookings_trip"),
                    models.Index(fields=["customer"], name="idx_bookings_customer"),
                ],
            },
        ),
        migrations.CreateModel(
            name="Ticket",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                ("ticket_code", models.CharField(max_length=30, unique=True)),
                (
                    "booking",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="tickets.TicketBooking",
                        related_name="tickets",
                    ),
                ),
                (
                    "seat",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="vehicles.Seat",
                        null=True,
                        blank=True,
                    ),
                ),
                ("seat_code", models.CharField(max_length=10, blank=True, null=True)),
                ("seat_type", models.CharField(max_length=30, default="SEAT")),
                (
                    "boarding_station",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="routes.Station",
                        null=True,
                        blank=True,
                        related_name="boarding_tickets",
                    ),
                ),
                (
                    "alighting_station",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="routes.Station",
                        null=True,
                        blank=True,
                        related_name="alighting_tickets",
                    ),
                ),
                ("passenger_name", models.CharField(max_length=255, blank=True, null=True)),
                ("passenger_phone", models.CharField(max_length=20, blank=True, null=True)),
                ("base_price", models.DecimalField(max_digits=15, decimal_places=2)),
                ("discount_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("final_price", models.DecimalField(max_digits=15, decimal_places=2)),
                ("status", models.CharField(max_length=30, choices=TICKET_STATUS_CHOICES, default="ACTIVE")),
                ("checked_in_at", models.DateTimeField(null=True, blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "tickets",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["booking"], name="idx_tickets_booking"),
                    models.Index(fields=["status"], name="idx_tickets_status"),
                ],
            },
        ),
        migrations.CreateModel(
            name="TicketRefund",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "ticket",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="tickets.Ticket",
                        related_name="refunds",
                    ),
                ),
                ("refund_code", models.CharField(max_length=30, unique=True)),
                ("reason", models.TextField(blank=True, null=True)),
                ("original_amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("penalty_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("refund_amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("refund_method", models.CharField(max_length=30, blank=True, null=True)),
                (
                    "processed_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("status", models.CharField(max_length=20, choices=REFUND_STATUS_CHOICES, default="PENDING")),
                ("processed_at", models.DateTimeField(null=True, blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "ticket_refunds", "ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="TicketExchange",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                (
                    "original_ticket",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="tickets.Ticket",
                        related_name="exchanges_as_original",
                    ),
                ),
                (
                    "new_ticket",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="tickets.Ticket",
                        null=True,
                        blank=True,
                        related_name="exchanges_as_new",
                    ),
                ),
                ("exchange_code", models.CharField(max_length=30, unique=True)),
                ("reason", models.TextField(blank=True, null=True)),
                ("fee", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                (
                    "processed_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("status", models.CharField(max_length=20, default="PENDING")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "ticket_exchanges", "ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="GroupContract",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("contract_code", models.CharField(max_length=30, unique=True)),
                ("customer_name", models.CharField(max_length=255)),
                ("customer_phone", models.CharField(max_length=20)),
                ("customer_email", models.EmailField(blank=True, null=True)),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="trips.Trip",
                        related_name="group_contracts",
                    ),
                ),
                ("seat_count", models.SmallIntegerField()),
                ("total_amount", models.DecimalField(max_digits=15, decimal_places=2)),
                ("deposit_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("status", models.CharField(max_length=30, choices=GROUP_CONTRACT_STATUS_CHOICES, default="DRAFT")),
                ("contract_file", models.CharField(max_length=500, blank=True, null=True)),
                ("notes", models.TextField(blank=True, null=True)),
                (
                    "created_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "group_contracts", "ordering": ["-created_at"]},
        ),
    ]
