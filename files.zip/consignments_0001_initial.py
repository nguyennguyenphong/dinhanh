from django.db import migrations, models
import django.db.models.deletion


CONSIGNMENT_STATUS_CHOICES = [
    ("RECEIVED", "Received"),
    ("LOADED", "Loaded"),
    ("IN_TRANSIT", "In Transit"),
    ("DELIVERED", "Delivered"),
    ("RETURNED", "Returned"),
    ("LOST", "Lost"),
]

MANIFEST_STATUS_CHOICES = [
    ("OPEN", "Open"),
    ("CLOSED", "Closed"),
]

COD_STATUS_CHOICES = [
    ("PENDING", "Pending"),
    ("TRANSFERRED", "Transferred"),
]

PRICE_UNIT_CHOICES = [
    ("PER_KG", "Per Kilogram"),
    ("PER_TRIP", "Per Trip"),
    ("FLAT", "Flat Rate"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("routes", "0001_initial"),
        ("trips", "0001_initial"),
        ("branches", "0001_initial"),
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="CargoPriceTable",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "route",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="routes.Route",
                        null=True,
                        blank=True,
                        related_name="cargo_prices",
                    ),
                ),
                ("cargo_type", models.CharField(max_length=50, blank=True, null=True)),
                ("min_weight", models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)),
                ("max_weight", models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)),
                ("min_volume", models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True)),
                ("max_volume", models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True)),
                ("price", models.DecimalField(max_digits=15, decimal_places=2)),
                ("price_unit", models.CharField(max_length=20, choices=PRICE_UNIT_CHOICES, default="PER_KG")),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "cargo_price_tables"},
        ),
        migrations.CreateModel(
            name="Consignment",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                ("waybill_code", models.CharField(max_length=30, unique=True)),
                ("barcode", models.CharField(max_length=100, unique=True, null=True, blank=True)),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="trips.Trip",
                        null=True,
                        blank=True,
                        related_name="consignments",
                    ),
                ),
                ("sender_name", models.CharField(max_length=255)),
                ("sender_phone", models.CharField(max_length=20)),
                ("receiver_name", models.CharField(max_length=255)),
                ("receiver_phone", models.CharField(max_length=20)),
                (
                    "origin_station",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="routes.Station",
                        null=True,
                        blank=True,
                        related_name="consignment_origins",
                    ),
                ),
                (
                    "destination_station",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="routes.Station",
                        null=True,
                        blank=True,
                        related_name="consignment_destinations",
                    ),
                ),
                ("cargo_type", models.CharField(max_length=50, blank=True, null=True)),
                ("description", models.TextField(blank=True, null=True)),
                ("weight_kg", models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)),
                ("volume_m3", models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True)),
                ("declared_value", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("freight_charge", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("cod_amount", models.DecimalField(max_digits=15, decimal_places=2, default=0)),
                ("cod_collected", models.BooleanField(default=False)),
                ("cod_transferred", models.BooleanField(default=False)),
                ("status", models.CharField(max_length=30, choices=CONSIGNMENT_STATUS_CHOICES, default="RECEIVED")),
                (
                    "received_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                        related_name="received_consignments",
                    ),
                ),
                (
                    "delivered_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                        related_name="delivered_consignments",
                    ),
                ),
                ("received_at", models.DateTimeField(null=True, blank=True)),
                ("delivered_at", models.DateTimeField(null=True, blank=True)),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True,
                        blank=True,
                    ),
                ),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "consignments",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["status"], name="idx_consignments_status"),
                    models.Index(fields=["trip"], name="idx_consignments_trip"),
                ],
            },
        ),
        migrations.CreateModel(
            name="ConsignmentManifest",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("manifest_code", models.CharField(max_length=30, unique=True)),
                (
                    "trip",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="trips.Trip",
                        related_name="manifests",
                    ),
                ),
                (
                    "created_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("status", models.CharField(max_length=20, choices=MANIFEST_STATUS_CHOICES, default="OPEN")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "consignment_manifests", "ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="ManifestItem",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "manifest",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="consignments.ConsignmentManifest",
                        related_name="items",
                    ),
                ),
                (
                    "consignment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="consignments.Consignment",
                    ),
                ),
                ("loaded_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "db_table": "manifest_items",
                "unique_together": {("manifest", "consignment")},
            },
        ),
        migrations.CreateModel(
            name="CODReconciliation",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                (
                    "consignment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        to="consignments.Consignment",
                        related_name="cod_reconciliations",
                    ),
                ),
                ("amount", models.DecimalField(max_digits=15, decimal_places=2)),
                (
                    "transferred_by",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="accounts.UserAccount",
                        null=True,
                        blank=True,
                    ),
                ),
                ("transferred_at", models.DateTimeField(null=True, blank=True)),
                ("status", models.CharField(max_length=20, choices=COD_STATUS_CHOICES, default="PENDING")),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "cod_reconciliations"},
        ),
        # Add proper FK from payments.Payment to consignments.Consignment
        migrations.AddField(
            model_name="payments.Payment",
            name="consignment",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.SET_NULL,
                to="consignments.Consignment",
                null=True,
                blank=True,
                related_name="payments",
            ),
        ),
    ]
