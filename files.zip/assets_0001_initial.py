from django.db import migrations, models
import django.db.models.deletion


ASSET_STATUS_CHOICES = [
    ("IN_USE", "In Use"),
    ("MAINTENANCE", "Under Maintenance"),
    ("DISPOSED", "Disposed"),
    ("LOST", "Lost"),
]


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("branches", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="AssetCategory",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("name", models.CharField(max_length=100, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"db_table": "asset_categories", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="Asset",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("name", models.CharField(max_length=255)),
                (
                    "category",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="assets.AssetCategory",
                        null=True, blank=True,
                        related_name="assets",
                    ),
                ),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True, blank=True,
                    ),
                ),
                ("serial_number", models.CharField(max_length=100, blank=True, null=True)),
                ("purchase_date", models.DateField(null=True, blank=True)),
                ("purchase_price", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("current_value", models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)),
                ("status", models.CharField(max_length=30, choices=ASSET_STATUS_CHOICES, default="IN_USE")),
                ("notes", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "assets", "ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="StorageUnit",
            fields=[
                ("id", models.AutoField(primary_key=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("name", models.CharField(max_length=100)),
                (
                    "branch",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="branches.Branch",
                        null=True, blank=True,
                    ),
                ),
                ("description", models.TextField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"db_table": "storage_units", "ordering": ["name"]},
        ),
    ]
